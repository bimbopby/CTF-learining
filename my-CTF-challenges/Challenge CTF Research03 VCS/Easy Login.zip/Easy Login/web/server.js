const express = require('express')
const lodash = require('lodash')
const bodyParser = require("express");
const session = require('express-session')

function Admin() {
    this.username = 'admin';
    this.password = process.env.ADMIN_PASSWORD;
    this.role = 1;
}

function Guest() {
    this.username = 'guest';
    this.password = 'guest';
    this.role = 0;
}

const admin = new Admin();
const guest = new Guest();

const app = express();

app.use(bodyParser.urlencoded({extended: true})).use(bodyParser.json())
app.use('/static', express.static('static'))
app.use(session({
    name: 'super-session',
    secret: process.env.SECRET,
    resave: false,
    saveUninitialized: false
}))

app.set('view engine', 'ejs');

app.all('/', function(req, res) {
    let data = req.session.data || {username: [], password: []};
    if (req.method == 'POST') {
        data = lodash.merge(data, req.body);
        req.session.data = data;
        if (data.username === admin.username && data.password === admin.password) {
            data.role = admin.role;
        }
        if (data.username === guest.username && data.password === guest.password) {
            data.role = guest.role;
        }
        if (data.role === 1) {
            res.send(process.env.FLAG);
        } else if (data.role === 0) {
            res.render('guest');
        } else {
            res.redirect('https://www.youtube.com/watch?v=dQw4w9WgXcQ');
        }
    }
    res.render('login');
})

app.listen(3000, () => console.log(`Listening on port 3000`))