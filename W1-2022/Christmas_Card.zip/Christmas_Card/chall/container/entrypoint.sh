#!/bin/bash

service cron start
sleep 1
apache2-foreground