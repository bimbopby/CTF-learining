#!/bin/bash
sudo docker rmi -f chall_web:chall_web
sudo docker-compose up -d
